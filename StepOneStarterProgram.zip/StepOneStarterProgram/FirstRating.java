import edu.duke.*;
import java.util.*;


public class FirstRating {

    public ArrayList<Movie> loadMovie(String fileName){
        //TODO Implement this method....
        return null;
    }
}
